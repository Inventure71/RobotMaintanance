import { initDashboardApp } from './modules/dashboard-app.js';

initDashboardApp();
